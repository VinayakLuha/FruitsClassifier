package com.example.fruits_classifier

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
