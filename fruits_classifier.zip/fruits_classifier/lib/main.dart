import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:tflite/tflite.dart';

void main() => runApp(MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MyApp(),
    ));

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  List _outputs;
  File _image;
  bool _loading = false;
  final ip = ImagePicker();

  pickImageGAL() async {
    PickedFile image = await ip.getImage(source: ImageSource.gallery);
    if (image == null) return null;
    setState(() {
      _loading = true;
      _image = File(image.path);
    });
    classifyImage(_image);
  }

  pickImageCAM() async {
    PickedFile image = await ip.getImage(source: ImageSource.camera);
    if (image == null) return null;
    setState(() {
      _loading = true;
      _image = File(image.path);
    });
    classifyImage(_image);
  }

  classifyImage(File image) async {
    var output = await Tflite.runModelOnImage(
      path: image.path,
      numResults: 2,
      threshold: 0.8,
      imageMean: 127.5,
      imageStd: 127.5,
    );
    setState(() {
      _loading = false;
      _outputs = output;


    });
  }

  loadModel() async {
    await Tflite.loadModel(
      model: "lib/assets/model_unquant.tflite",
      labels: "lib/assets/labels.txt",
    );
  }

  @override
  void dispose() {
    Tflite.close();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _loading = true;

    loadModel().then((value) {
      setState(() {
        _loading = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    // print(_outputs);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue[900],
        title: Text('Fruits Classifier'),
        centerTitle: true,
      ),
      body: Padding(
        padding: EdgeInsets.all(25),
        child: Column(
          children: [
            Container(
              height: MediaQuery.of(context).size.height * 0.65,
              color: Colors.blueAccent[100].withOpacity(0.4),
              child: _loading || (_image == null)
                  ? Center(
                      child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            CircularProgressIndicator(),
                            SizedBox(
                              height: 20,
                            ),
                            Text("Choose an image from gallery or camera")
                          ]),
                    )
                  : Container(
                      height: MediaQuery.of(context).size.height * 0.65,
                      child: _image == null
                          ? Container()
                          : Image.file(
                              _image,
                              fit: BoxFit.contain,
                            ),
                    ),
            ),
            SizedBox(
              height: 20,
            ),
            _outputs != null?
            Container(
              height: MediaQuery.of(context).size.height * 0.05,
              width: double.infinity,
              color: Colors.blueAccent[100],
              child: Center(
                child: _outputs.isEmpty ==false
                    ? Text(
                        "${((_outputs[0]["confidence"] * 100).toString()).substring(0, 5) + "\% " + _outputs[0]["label"].toString().substring(2)}",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 20.0,
                        ),
                      )
                    : Text(
                        "Image doesn't match any categories",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 20.0,
                        ),
                      ),
              ),
            )
            : Container(
                height: MediaQuery.of(context).size.height * 0.05,
                width: double.infinity,
                color: Colors.blueAccent[100],
              ),
            SizedBox(
              height: 20,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                ElevatedButton(
                    child: Padding(
                        padding: EdgeInsets.all(10),
                        child: Text(
                          'Camera',
                          style: TextStyle(fontSize: 20),
                        )),
                    onPressed: pickImageCAM,
                    style: ElevatedButton.styleFrom(primary: Colors.blue[900])),
                ElevatedButton(
                  child: Padding(
                      padding: EdgeInsets.all(10),
                      child: Text(
                        'Gallery',
                        style: TextStyle(fontSize: 20),
                      )),
                  onPressed: pickImageGAL,
                  style: ElevatedButton.styleFrom(primary: Colors.blue[900]),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

}
